<?php
namespace App\Http\Interface\Actors;


interface ClientInterface
{
      public function get_all();
}
