<?php

namespace App\Http\Interface\Helper;

use Illuminate\Http\Request;


interface AccountStatusInterface
{
      public function get_all();
}
